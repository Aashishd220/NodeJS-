
//const fs=require('fs')
//fs.writeFileSync('notes.txt','File contains data')
//fs.appendFileSync('newfile.js','. File contains data is appended')

// const add=require('./utils.js')
// console.log(add(2,5))

// const getNotes=require('./notes.js')

// const message=getNotes()
// console.log(message)

// const validator=require('validator')

// console.log(validator.isEmail('aashish@.com'))

// const chalk = require('chalk');
// const error = chalk.bold.red;
// const warning = chalk.keyword('orange');
//  console.log('working')
// console.log(error('Error!'));
// console.log(warning('Warning!'));
// console.log(process.argv[2]) 

const notes=require('./notes.js')
const yargs=require('yargs')

//Customize yargs version
yargs.version('1.1.0')

//Add command
yargs.command({
    command:'add',
    describe:'add a new note',
    builder:{
        title:{
            describe:'Note title',
            demandOption:'true',
            type:'string'

        },
        body:{
            describe:'Note body',
            demandOption:'true',
            type:'string'
        }
    },
   
    handler(argv){
        notes.addNotes(argv.title,argv.body)
    }
})


//Remove command
yargs.command({
    command:'remove',
    describe:'remove a note',
    builder:{
            title:{
                describe:'Note title',
                demandOption:'true',
                type:'string'
            }
    },
    handler(argv){
       notes.removeNotes(argv.title)
    }
})

//List command
yargs.command({
    command:'list',
    describe:'listing all the notes',
    handler(){
       notes.listNotes()
    }
})

//Read command
yargs.command({
    command:'read',
    describe:'read a note',
    builder:{
        title:{
            type:'string',
            describe:'Note title',
            demandOption:'true'
        }
    },
    handler(argv){
       notes.readNotes(argv.title)
    }
})
yargs.parse()