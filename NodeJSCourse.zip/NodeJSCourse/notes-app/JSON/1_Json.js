const fs=require('fs')
// const book={
//     title:"Malang",
//     author:"aashish"
// }
// const bookJSON=JSON.stringify(book)
// console.log(bookJSON)

// const parseJson=JSON.parse(bookJSON)
// console.log(parseJson)

// fs.writeFileSync('abc.json',bookJSON)

const dataBuffer=fs.readFileSync('abc.json')
const dataJson=dataBuffer.toString();
const parseData=JSON.parse(dataJson)

parseData.name="Aashish"
parseData.age=24


const newDataJSON=JSON.stringify(parseData)
fs.writeFileSync('abc.json',newDataJSON)

