const fs=require('fs')
const chalk=require('chalk')


//add Notes 
const addNotes=(title,body)=>{
    const notes=loadNotes()

    //to check if the title is already present
    //const duplicateNotes=notes.filter((note)=>note.title===title)
    const duplicateNote=notes.find((note)=>note.title===title)
    if(!duplicateNote){

        notes.push({
            title:title,
            body:body
        })
       saveNotes(notes)
       console.log(chalk.green.inverse('note added!'))
    }
    else{
        console.log(chalk.red.inverse('title exist'))
    }
}
//remove notes
const removeNotes=(title)=>{
    const notes=loadNotes()
  
const containsNote=notes.filter((note)=>note.title!=title)

if(containsNote.length!=notes.length){
    console.log(chalk.inverse.green('Note removed'))
}
else{
    console.log(chalk.inverse.red('No note found'))
}
saveNotes(containsNote) 

}
//list notes
const listNotes=()=>{
    const notes=loadNotes()
  console.log(chalk.green.inverse('Your Notes'))
  notes.forEach((note)=>{
      console.log(note.title)
  })
    
}

//read Notes
const readNotes=(title)=>{
const notes=loadNotes()

const note=notes.find((note)=>title===note.title)
if(findNote){
console.log(chalk.green.inverse(title))
console.log(findNote.body)
}
else{
    console.log(chalk.red.inverse('No Note found!!'))
}


}

//saveNotes to save an added notes in the add functionality
const saveNotes=(notes)=>{
    const dataJson=JSON.stringify(notes)
    fs.writeFileSync('notes.json',dataJson)
}

//loadNotes to check if the notes is already there in the file or not
const loadNotes=()=>{
    try{
        const bufferData=fs.readFileSync('notes.json')
        const dataJson=bufferData.toString();
        return JSON.parse(dataJson)
    }
    catch(e){
        return []
    }
}

//export to app.js file
module.exports={
    addNotes:addNotes,
    removeNotes:removeNotes,
    listNotes:listNotes,
    readNotes:readNotes
}