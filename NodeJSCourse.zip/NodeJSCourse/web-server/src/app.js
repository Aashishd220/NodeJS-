const express=require('express')
const path=require('path')
const hbs=require('hbs')

const app=express()

//Define path for express configs
const dirNamePath=path.join(__dirname,'../public')
const viewsPath = path.join(__dirname, '../templates/views')
const partialsPath=path.join(__dirname,'../templates/partials') 

//setup handlebars engine and view location
app.set('views', viewsPath)
app.set('view engine', 'hbs')
hbs.registerPartials(partialsPath)

//setup static directory to serve
app.use(express.static(dirNamePath))

     
app.get('/',(req,res)=>{
   res.render("index",{
       title:'Weather App',
       name:'aashish'
   })
   
})

app.get('/about',(req,res)=>{
    res.render('about',{
        title:'About Me',
        name:'aashish'
    })
})

app.get('/help',(req,res)=>{
    res.render('help',{
        title:'Help',
        name:'aashish'
    })
})
 
app.get('/weather',(req,res)=>{
    res.send({
        forecast:23, 
        location:'Bangalore'
    })
})
app.get('/help/*',(req,res)=>{
    res.render('error',{
        title:'404',
        message:'Help article not found',
        name:'aashish'
    })
})
app.get('*',(req,res)=>{
   res.render('error',{
       title:'404',
       message:'404 not found!!',
       name:'aashish'
   })
})
app.listen(3000,()=>{
    console.log('Server is up on 3000!')
})