const express=require('express')
const path=require('path')
const hbs=require('hbs')
const geoCode=require('./utils/geoCode')
const weather=require('./utils/weather')
const chalk=require('chalk')

const app=express()

//Define path for express configs
const dirNamePath=path.join(__dirname,'../public')
const viewsPath = path.join(__dirname, '../templates/views')
const partialsPath=path.join(__dirname,'../templates/partials') 

//setup handlebars engine and view location
app.set('views', viewsPath)
app.set('view engine', 'hbs')
hbs.registerPartials(partialsPath)

//setup static directory to serve
app.use(express.static(dirNamePath))

     
app.get('/',(req,res)=>{
   res.render("index",{
       title:'Weather App',
       name:'aashish'
   })
   
})

app.get('/about',(req,res)=>{
    res.render('about',{
        title:'About Me',
        name:'aashish'
    })
})

app.get('/help',(req,res)=>{
    res.render('help',{
        title:'Help',
        name:'aashish'
    })
})
 
app.get('/weather',(req,res)=>{
    const address=req.query.address
    if(!address){
        return res.send({
            error:'Please provide the search address'
        })
    }
    geoCode(address,(error,{latitude,longitude,location}={})=>{
        if(error){
            return res.send({error})
        }
        weather(latitude,longitude,(error,weatherData)=>{
           if(error){
               return res.send({error})
           }
           res.send({
               forecast:weatherData,
               location,
               address:address,
           })
        })
    })
    
   
   
   
})

app.get('/products',(req,res)=>{
    if(!req.query.search){
        return res.send({
            error:'Please provide search option'
        })
    }
    console.log(req.query.search)
    res.send({
        products:[]
    })
})
app.get('/help/*',(req,res)=>{
    res.render('error',{
        title:'404',
        message:'Help article not found',
        name:'aashish'
    })
})
app.get('*',(req,res)=>{
   res.render('error',{
       title:'404',
       message:'404 not found!!',
       name:'aashish'
   })
})
app.listen(3000,()=>{
    console.log('Server is up on 3000!')
})