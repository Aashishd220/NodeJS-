const request=require('request')
const chalk=require('chalk')
const geoCode=require('./utils/geoCode.js')
const weather=require('./utils/weather.js')

const address=process.argv[2]

if(!address){
    return console.log(chalk.red.inverse('No address provided!! Please provide the address.'))
}

geoCode(address,(error,{latitude,longitude,location})=>{
    if(error){
        return console.log(error)
    }
    weather(latitude,longitude,(error,weatherData)=>{
       if(error){
           return console.log(error)
       }
       console.log(location)
       console.log(weatherData)
    })
})

