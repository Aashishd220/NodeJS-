const request=require('request')
const chalk=require('chalk')
const weather=(latitude,longitude,callback)=>{
    const url='https://api.darksky.net/forecast/d4df87fc0c74df7cd65ce24b73f6bbb7/'+latitude+','+longitude+'?units=si'
   
    request({url,json:true},(error,{body})=>{
        if(error){
            callback(chalk.red.inverse('Unable to connect to the server!!'),undefined)
        }
        else if(body.error){
            callback('Getting an error from the request: '+ body.error,undefined )
        }
        else{
            callback(undefined,body.daily.summary+' It is currently '+body.currently.temperature+' degrees out. There is '+body.currently.precipProbability+' % of rain')
        }
       
    })
}

module.exports=weather

//---------------------------
// const url='https://api.darksky.net/forecast/d4df87fc0c74df7cd65ce24b73f6bbb7/27.2038,77&units=si'

// request({url:url,json:true},(err,response)=>{
//     if(err){
//         console.log(chalk.red.inverse('Unable to connect to the server!!'))
//     }
//     else if(response.body.error){
//         console.log('Getting an error from the request: '+ response.body.error )
//     }
//     else{
//         console.log(response.body.daily.summary+' It is currently '+response.body.currently.temperature+' degrees out. There is '+response.body.currently.precipProbability+' % of rain')
//     }
    
// })
