const request=require('request')
const geoCode=(address,callback)=>{
    const url='https://api.mapbox.com/geocoding/v5/mapbox.places/'+encodeURIComponent(address)+'.json?access_token=pk.eyJ1IjoiYWFzaGlzaDIwIiwiYSI6ImNrNng3a2d1ZTBiZzUzbXM2ZHN1dXVkcDQifQ.hZp2_SNzqr8YTxnIS5fVAQ'
    request({url,json:true},(error,{body})=>{
        if(error){
            callback(chalk.red.inverse('Unable to connect to the server!!',undefined))
        }
        else if(body.features.length===0){
            callback('Getting an error from the request: '+ body.message,undefined)
        }
        else{
            callback(undefined,{
                latitude:body.features[0].center[1],
                longitude:body.features[0].center[0],
                location:body.features[0].place_name
    
            })
        }
    })
    }
    module.exports=geoCode

    
//---------------------------
// const geologicalUrl='https://api.mapbox.com/geocoding/v5/mapbox.places/Los%20Angeles.json?access_token=pk.eyJ1IjoiYWFzaGlzaDIwIiwiYSI6ImNrNng3a2d1ZTBiZzUzbXM2ZHN1dXVkcDQifQ.hZp2_SNzqr8YTxnIS5fVAQ&limit=1'
// request({geologicalUrl:newUrl,json:true},(err,response)=>{
// if(err){
//     console.log(chalk.red.inverse('Unable to connect to the server!!'))
// }
// else if(response.body.features.length===0){
//     console.log('Getting an error from the request: '+ response.body.message )
// }
// else{

//     const latitude=response.body.features[0].center[1]
//     const longitude=response.body.features[0].center[0]
//     console.log(latitude,longitude)
    
// }
// })