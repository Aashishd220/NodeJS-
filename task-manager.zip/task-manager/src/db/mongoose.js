const mongoose=require('mongoose')
const validator=require('validator')
mongoose.connect('mongodb://127.0.0.1:27017/task-manager-api',{
    useNewUrlParser:true,
    useCreateIndex:true
})

const User=mongoose.model('User',{
    name:{
        type:String,
        required:true,
        name:true
    },
    email:{
        type:String,
        required:true,
        trim:true,
        lowercase:true,
        validate(value){
            if(!validator.isEmail(value)){
                throw new Error('Not a valid email address')
            }
        }
    },
    age:{
        type:Number,
        default:0,
        validate(value){
            if(value<0){
                throw new Error('Age must be a positive number')
            }
        }
    },
    password:{
        type:String,
        required:true,
        trim:true,
        validate(value){
            if(value.length<7){
                throw new Error('Password length should be bigger than 6 characters')
            }
            if(value.toLowerCase().includes('password')){
                throw new Error('Password cannot be "password"')
            }
        }


    }
})
// const me=new User({
//     name:'Aashish',
//     age:10,
//     email:'aashish.d@gamil.com',
//     password:'sfg'
// })

// me.save().then(()=>{
//     console.log(me)
// }).catch((error)=>{
//     console.log(error)
// })
const Task=mongoose.model('Task',{
    description:{
        type:String,
        trim:true,

    },
    completed:{
        type:Boolean,
        default:false,
        required:fasle
    }
})

const task2=new Task({
    description:' SecondTask    ',
    
})
task2.save().then(()=>{
    console.log(task2)
}).catch((error)=>{
    console.log(error)
})