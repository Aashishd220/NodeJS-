//CRUD

// const mongodb=require('mongodb')
// const MongoClient=mongodb.MongoClient

const{MongoClient,ObjectID}=require('mongodb')

const connectionURL='mongodb://127.0.0.1:27017'
const databaseName='task-manager'
 
// const id=new ObjectID()
// console.log(id)

MongoClient.connect(connectionURL,{useNewUrlParser:true},(error,client)=>{
        if(error){
            return console.log('Error while connecting to DB')
        }
     const db=client.db(databaseName)
    //  db.collection('users').insertOne({
    //      name:'Aashish',
    //      age:24
    //  })
    // db.collection('users').insertMany([
    //     {
    //         name:'Rohit',
    //         age:31
    //     },
    //     {
    //         name:'Virat',
    //         age:29
    //     }
    // ],(error,result)=>{
    //     if(error){
    //         return console.log('unable to add documents')
    //     }
    //     console.log(result.ops)
    // })
    // db.collection('tasks').insertMany([
    //     {
    //         description:'Task1',
    //         completed:true
    //     },
    //     {
    //         description:'Task2',
    //         completed:false
    //     },
    //     {
    //         description:'Task3',
    //         completed:true
    //     }
    // ],(error,result)=>{
    //     if(error){
    //         return console.log('unable to add data')
    //     }
    //     console.log(result.ops)
    // })
        // db.collection('tasks').findOne({_id:new ObjectID("5e5a3e6fd825424494ff1cd3")},(error,task)=>{
        //     if(error){
        //         return console.log('task not found')
        //     }
        //     console.log(task)
        // })
        // db.collection('tasks').find({completed:false}).toArray((error,task)=>{
        //         if(error){
        //             return console.log(error)
        //         }
        //         console.log(task)
        // })
        // db.collection('users').updateOne({
        //     _id:new ObjectID('5e5c537380e7364fb8a4a112')
        // },{
        //     $set:{
        //         name:'Dhoni'
        //     }
        // }).then((result)=>{
        //     console.log(result) 
        // }).catch((error)=>{
        //     console.log(error)
        // })

        // db.collection('tasks').updateMany({
        //     completed:false
        // },{
        //     $set:{
        //         completed:true
        //     }
        // }).then((result)=>{
        //     console.log(result.modifiedCount)
        // }).catch((error)=>{
        //     console.log(error)
        // })

        db.collection('tasks').deleteOne({
            description:'Task3'
        }).then((result)=>{
            console.log(result)
        }).catch((error)=>{
            console.log(error)
        })

})