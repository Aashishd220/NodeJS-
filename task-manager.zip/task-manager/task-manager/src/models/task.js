const mongoose=require('mongoose')
const validator=require('validator')

const Task=mongoose.model('Task',{
    description:{
        type:String,
        trim:true,

    },
    completed:{
        type:Boolean,
        default:false,
        required:fasle
    }
})

module.exports=Task

// const task2=new Task({
//     description:' SecondTask    ',
    
// })
// task2.save().then(()=>{
//     console.log(task2)
// }).catch((error)=>{
//     console.log(error)
// })