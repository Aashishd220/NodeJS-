import React, { Component } from 'react';
import FontAwesome from 'react-fontawesome';
import './SearchBar.css'

class SearchBar extends Component {
  state = {

  }

  render(){
    return (
      <div>
        SearchBar
      </div>
    )
  }
}

export default SearchBar;