import React from 'react';
import { IMAGE_BASE_URL } from '../../../config';
import './Actor.css';

const Actor = (props) => {
  return (
    <div>
      Actor
    </div>
  )
}

export default Actor;