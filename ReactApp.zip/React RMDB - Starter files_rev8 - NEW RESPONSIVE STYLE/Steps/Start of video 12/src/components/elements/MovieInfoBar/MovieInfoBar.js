import React from 'react';
import FontAwesome from 'react-fontawesome';
import { calcTime, convertMoney } from '../../../helpers.js';
import './MovieInfoBar.css';

const MovieInfoBar = (props) => {
  return (
    <div>
      MovieInfoBar
    </div>
  )
}

export default MovieInfoBar;