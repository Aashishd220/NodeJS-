import React, { Component } from 'react';
import './Home.css';

class Home extends Component {
  state = {

  }

  render() {
    return (
      <div>
        Home
      </div>
    )
  }
}

export default Home;